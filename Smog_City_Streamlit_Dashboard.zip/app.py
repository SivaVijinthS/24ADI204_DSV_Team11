import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(
    page_title="SMOG CITY | India Air Quality",
    page_icon="🌫️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------- Theme ----------
st.markdown("""
<style>
    .stApp { background: #0b1420; color: #eef5f8; }
    [data-testid="stSidebar"] { background: #111f2e; }
    h1, h2, h3 { color: #f2f7fa !important; }
    .hero {
        padding: 1.25rem 1.5rem; border-radius: 18px;
        background: linear-gradient(115deg,#142b3d,#123b47);
        border: 1px solid #285568; margin-bottom: 1rem;
    }
    .hero p { color: #b9cbd5; margin-bottom: 0; }
    div[data-testid="stMetric"] {
        background: #142436; border: 1px solid #284256;
        padding: 14px 16px; border-radius: 14px;
    }
    div[data-testid="stMetricLabel"] { color: #a9c0cd; }
    div[data-testid="stMetricValue"] { color: #f4fbff; }
    .note { color: #a9c0cd; font-size: .88rem; }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>🌫️ SMOG CITY</h1>
  <h3>Air Quality Analysis of Indian Cities</h3>
  <p>Explore AQI patterns, compare cities, and investigate pollutant measurements.</p>
</div>
""", unsafe_allow_html=True)

# ---------- Helpers ----------
def find_col(columns, candidates):
    lower = {str(c).lower().strip(): c for c in columns}
    for cand in candidates:
        if cand in lower:
            return lower[cand]
    for c in columns:
        cl = str(c).lower().strip()
        if any(k in cl for k in candidates):
            return c
    return None

def numeric_series(frame, col):
    return pd.to_numeric(frame[col], errors="coerce") if col else pd.Series(dtype=float)

def style_fig(fig, height=390):
    fig.update_layout(
        template="plotly_dark", height=height,
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#eaf2f6"),
        margin=dict(l=15, r=15, t=55, b=15),
        legend_title_text="",
    )
    return fig

# ---------- Upload ----------
with st.sidebar:
    st.header("📂 Dataset")
    uploaded = st.file_uploader("Upload your cleaned AQI CSV", type=["csv"])
    st.caption("Recommended file: aqi_india_38cols_knn_final.csv")
    st.divider()
    st.header("🔎 Filters")

if uploaded is None:
    st.info("Upload your cleaned CSV in the left sidebar to populate the dashboard.")
    st.markdown("""
    **What this dashboard includes**
    - AQI summary cards
    - City-wise AQI comparison
    - AQI category distribution (if a category field exists)
    - Monthly and seasonal trends (if date/season fields exist)
    - Pollutant comparison and correlation heatmap
    - Downloadable filtered data
    """)
    st.stop()

try:
    df = pd.read_csv(uploaded, low_memory=False)
except Exception as e:
    st.error(f"Could not read this CSV: {e}")
    st.stop()

if df.empty:
    st.error("The uploaded CSV contains no rows.")
    st.stop()

# Standardize column matching without changing original column names
cols = list(df.columns)
city_col = find_col(cols, ["city", "city_name", "location"])
state_col = find_col(cols, ["state", "state_name"])
date_col = find_col(cols, ["datetime", "date_time", "timestamp", "date"])
aqi_col = find_col(cols, ["us_aqi", "aqi", "air_quality_index"])
category_col = find_col(cols, ["aqi_category", "aqi category", "category", "air_quality_category"])
season_col = find_col(cols, ["season"])
time_col = find_col(cols, ["time_of_day", "time of day"])

# Identify likely pollutant columns
pollutant_keys = ["pm2.5", "pm25", "pm_2_5", "pm10", "no2", "so2", "co", "o3", "nh3"]
pollutant_cols = []
for c in cols:
    cl = str(c).lower().replace(" ", "")
    if any(k in cl for k in pollutant_keys):
        if pd.api.types.is_numeric_dtype(df[c]) or pd.to_numeric(df[c], errors="coerce").notna().any():
            pollutant_cols.append(c)

# Parse dates, AQI, pollutant values
work = df.copy()
if date_col:
    work[date_col] = pd.to_datetime(work[date_col], errors="coerce")
if aqi_col:
    work[aqi_col] = pd.to_numeric(work[aqi_col], errors="coerce")
for c in pollutant_cols:
    work[c] = pd.to_numeric(work[c], errors="coerce")

# Filter controls
with st.sidebar:
    filtered = work.copy()
    if city_col:
        city_values = sorted(filtered[city_col].dropna().astype(str).unique().tolist())
        selected_cities = st.multiselect("City", city_values, default=city_values)
        if selected_cities:
            filtered = filtered[filtered[city_col].astype(str).isin(selected_cities)]
    if state_col:
        state_values = sorted(filtered[state_col].dropna().astype(str).unique().tolist())
        selected_states = st.multiselect("State", state_values, default=state_values)
        if selected_states:
            filtered = filtered[filtered[state_col].astype(str).isin(selected_states)]
    if date_col and filtered[date_col].notna().any():
        min_date = filtered[date_col].min().date()
        max_date = filtered[date_col].max().date()
        date_range = st.date_input("Date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)
        if isinstance(date_range, tuple) and len(date_range) == 2:
            start, end = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1]) + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
            filtered = filtered[filtered[date_col].between(start, end)]

# KPI row
st.subheader("📊 Air Quality Snapshot")
k1, k2, k3, k4 = st.columns(4)
if aqi_col and filtered[aqi_col].notna().any():
    avg_aqi = filtered[aqi_col].mean()
    max_aqi = filtered[aqi_col].max()
    k1.metric("Average AQI", f"{avg_aqi:,.1f}")
    k2.metric("Maximum AQI", f"{max_aqi:,.1f}")
else:
    k1.metric("Average AQI", "N/A")
    k2.metric("Maximum AQI", "N/A")
k3.metric("Records shown", f"{len(filtered):,}")
k4.metric("Cities shown", f"{filtered[city_col].nunique():,}" if city_col else "N/A")

st.caption(f"Dataset: {len(df):,} rows × {len(df.columns)} columns | Filtered view: {len(filtered):,} rows")

# Layout charts
left, right = st.columns(2)

with left:
    st.subheader("🏙️ City-wise AQI")
    if city_col and aqi_col:
        city_stats = (filtered.groupby(city_col, dropna=True)[aqi_col]
                      .mean().dropna().sort_values(ascending=False).head(20).reset_index())
        city_stats.columns = ["City", "Average AQI"]
        fig = px.bar(city_stats.sort_values("Average AQI"), x="Average AQI", y="City",
                     orientation="h", title="Top 20 cities by average AQI")
        st.plotly_chart(style_fig(fig), use_container_width=True)
    else:
        st.warning("City and AQI columns are needed for this chart.")

with right:
    st.subheader("🧭 AQI Category Distribution")
    if category_col:
        cat_counts = filtered[category_col].fillna("Unknown").astype(str).value_counts().reset_index()
        cat_counts.columns = ["Category", "Records"]
        fig = px.pie(cat_counts, names="Category", values="Records", hole=0.52,
                     title="Records by AQI category")
        st.plotly_chart(style_fig(fig), use_container_width=True)
    elif aqi_col:
        vals = filtered[aqi_col].dropna()
        if len(vals):
            fig = px.histogram(filtered, x=aqi_col, nbins=35, title="AQI value distribution")
            st.plotly_chart(style_fig(fig), use_container_width=True)
        else:
            st.warning("No usable AQI values in the filtered data.")
    else:
        st.warning("No AQI category or AQI numeric column was detected.")

# Time trend
st.subheader("📅 AQI Trend Over Time")
if date_col and aqi_col and filtered[date_col].notna().any():
    trend = (filtered.dropna(subset=[date_col, aqi_col])
             .set_index(date_col)[aqi_col].resample("MS").mean().reset_index())
    if not trend.empty:
        fig = px.line(trend, x=date_col, y=aqi_col, markers=True,
                      title="Monthly average AQI")
        st.plotly_chart(style_fig(fig, 420), use_container_width=True)
    else:
        st.info("Not enough valid date and AQI values to draw a trend.")
elif season_col and aqi_col:
    seasonal = filtered.groupby(season_col)[aqi_col].mean().reset_index()
    fig = px.bar(seasonal, x=season_col, y=aqi_col, title="Average AQI by season")
    st.plotly_chart(style_fig(fig), use_container_width=True)
else:
    st.info("A date/time column and AQI column are needed for a time trend. A season column can be used as an alternative.")

# Pollutants
st.subheader("🧪 Pollutant Analysis")
if pollutant_cols:
    selected_pollutants = st.multiselect("Choose pollutants", pollutant_cols, default=pollutant_cols[:min(5, len(pollutant_cols))])
    if selected_pollutants:
        means = filtered[selected_pollutants].mean(numeric_only=True).sort_values(ascending=False).reset_index()
        means.columns = ["Pollutant", "Mean concentration"]
        fig = px.bar(means, x="Pollutant", y="Mean concentration",
                     title="Average pollutant concentration (original units)")
        st.plotly_chart(style_fig(fig), use_container_width=True)
    else:
        st.info("Select at least one pollutant to display.")
else:
    st.info("No likely pollutant columns were detected automatically. Check the CSV column names.")

# Correlation heatmap
numeric_cols = filtered.select_dtypes(include=np.number).columns.tolist()
if len(numeric_cols) >= 2:
    with st.expander("📈 Explore numerical correlations", expanded=False):
        corr_cols = st.multiselect("Variables for correlation", numeric_cols,
                                   default=numeric_cols[:min(12, len(numeric_cols))])
        if len(corr_cols) >= 2:
            corr = filtered[corr_cols].corr()
            fig = px.imshow(corr, text_auto=".2f", aspect="auto",
                            color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                            title="Correlation matrix")
            st.plotly_chart(style_fig(fig, 520), use_container_width=True)

# Data preview and export
with st.expander("🧾 View filtered data", expanded=False):
    st.dataframe(filtered.head(500), use_container_width=True)
    csv = filtered.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download filtered CSV", csv, "smog_city_filtered_data.csv", "text/csv")

st.markdown("---")
st.markdown('<p class="note">SMOG CITY • Dashboard metrics are calculated from the uploaded dataset and current filters. This is an analysis dashboard, not a live AQI feed or forecast.</p>', unsafe_allow_html=True)
