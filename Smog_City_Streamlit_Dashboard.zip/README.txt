SMOG CITY - Streamlit Dashboard

FILES
- app.py: Streamlit dashboard application
- requirements.txt: required Python packages

RUN LOCALLY
1. Install Python.
2. Open a terminal in this folder.
3. Run: pip install -r requirements.txt
4. Run: streamlit run app.py
5. The dashboard opens in your browser.
6. Upload aqi_india_38cols_knn_final.csv using the sidebar.

DEPLOYMENT
You can deploy this folder using Streamlit Community Cloud by connecting a GitHub repository
containing app.py and requirements.txt.

NOTES
- The app attempts to detect city, date, AQI, AQI category, season and pollutant columns.
- Column names may differ; if a chart says a required column was not detected, adjust the
  matching candidates in app.py to match your CSV.
- Metrics are calculated from the actual uploaded CSV and selected filters.
- This is a dataset analysis dashboard, not a live AQI monitoring or forecasting service.
