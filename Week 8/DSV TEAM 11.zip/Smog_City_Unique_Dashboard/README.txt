SMOG CITY — UNIQUE AIR QUALITY EXPLORER

Files:
- app.py: Streamlit dashboard
- requirements.txt: Python dependencies

Run on Windows PowerShell:
1. Open PowerShell in this folder.
2. Install dependencies:
   python -m pip install -r requirements.txt
3. Start the dashboard:
   python -m streamlit run app.py
4. Open the local address printed in the terminal (usually http://localhost:8501).
5. Upload your AQI CSV in the sidebar.

The app tries to identify common column names automatically. It needs an AQI field
named AQI, US_AQI, or a similar recognizable name. City/date/pollutant features
appear only when matching columns are present.

This is a distinct redesign, not a guarantee that no other student has similar
features. Test it with your actual cleaned dataset before presenting it.
