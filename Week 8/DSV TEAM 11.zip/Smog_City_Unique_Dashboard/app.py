import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Smog City | Air Quality Explorer", page_icon="🌫️", layout="wide")

# ---------- Theme ----------
st.markdown("""
<style>
.stApp {background: linear-gradient(145deg, #071923 0%, #102b35 55%, #142c2b 100%); color:#eef7f4;}
[data-testid="stSidebar"] {background:#0b2029;}
.metric-card {background:#15343b; padding:16px 18px; border:1px solid #31545a; border-radius:14px;}
.section-note {color:#b8d1ce; font-size:0.92rem;}
h1,h2,h3 {color:#e9f5ef;}
</style>
""", unsafe_allow_html=True)

st.title("🌫️ SMOG CITY")
st.subheader("Air Quality Explorer | Discover patterns, compare cities, understand pollution")
st.markdown('<p class="section-note">An interactive exploration of historical air-quality observations. Upload your project CSV to begin.</p>', unsafe_allow_html=True)

# ---------- Helpers ----------
def find_col(columns, candidates):
    lower = {str(c).lower().replace(" ", "_"): c for c in columns}
    for candidate in candidates:
        key = candidate.lower().replace(" ", "_")
        if key in lower:
            return lower[key]
    for c in columns:
        cl = str(c).lower()
        if any(k in cl for k in candidates):
            return c
    return None

def numeric_col(df, candidates):
    col = find_col(df.columns, candidates)
    if col is not None:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return col

# ---------- Upload ----------
with st.sidebar:
    st.header("📁 Data source")
    uploaded = st.file_uploader("Upload AQI CSV", type=["csv"])
    st.caption("Use your cleaned project dataset where possible.")
    st.divider()
    st.header("🧭 Explorer controls")

if uploaded is None:
    st.info("Upload your AQI CSV in the sidebar. The dashboard will identify common city, date, AQI and pollutant columns.")
    st.markdown("""
    **What makes this version different**
    - City comparison studio with side-by-side KPIs
    - Calendar-style monthly pollution heatmap
    - Pollutant fingerprint radar chart
    - AQI distribution and data-quality panel
    """)
    st.stop()

try:
    df = pd.read_csv(uploaded, low_memory=False)
except Exception as exc:
    st.error(f"Could not read the CSV: {exc}")
    st.stop()

if df.empty:
    st.error("The uploaded CSV has no rows.")
    st.stop()

city_col = find_col(df.columns, ["city", "city_name", "location"])
state_col = find_col(df.columns, ["state", "state_name"])
date_col = find_col(df.columns, ["datetime", "date", "timestamp", "time"])
aqi_col = numeric_col(df, ["us_aqi", "aqi", "air_quality_index", "overall_aqi"])
category_col = find_col(df.columns, ["aqi_category", "category", "air_quality_category"])
season_col = find_col(df.columns, ["season"])
pollutant_candidates = ["pm2_5", "pm25", "pm2.5", "pm10", "no2", "so2", "co", "o3", "nh3"]
pollutants = []
for p in pollutant_candidates:
    c = find_col(df.columns, [p])
    if c is not None and c not in pollutants:
        df[c] = pd.to_numeric(df[c], errors="coerce")
        pollutants.append(c)

if date_col:
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
if not aqi_col:
    st.error("I couldn't identify an AQI column. Rename your AQI field to `AQI` or `US_AQI` and upload again.")
    st.write("Columns found:", list(df.columns))
    st.stop()

# ---------- Sidebar filters ----------
with st.sidebar:
    filtered = df.copy()
    if city_col:
        city_values = sorted(filtered[city_col].dropna().astype(str).unique())
        chosen_cities = st.multiselect("Choose cities", city_values, default=city_values[:min(8, len(city_values))])
        if chosen_cities:
            filtered = filtered[filtered[city_col].astype(str).isin(chosen_cities)]
    if date_col and filtered[date_col].notna().any():
        min_d, max_d = filtered[date_col].min().date(), filtered[date_col].max().date()
        selected_dates = st.date_input("Date range", value=(min_d, max_d), min_value=min_d, max_value=max_d)
        if isinstance(selected_dates, tuple) and len(selected_dates) == 2:
            start, end = pd.Timestamp(selected_dates[0]), pd.Timestamp(selected_dates[1]) + pd.Timedelta(days=1)
            filtered = filtered[(filtered[date_col] >= start) & (filtered[date_col] < end)]
    if category_col:
        cats = sorted(filtered[category_col].dropna().astype(str).unique())
        selected_cats = st.multiselect("AQI categories", cats, default=cats)
        if selected_cats:
            filtered = filtered[filtered[category_col].astype(str).isin(selected_cats)]

if filtered.empty:
    st.warning("No records match the selected filters.")
    st.stop()

# ---------- Overview ----------
st.markdown("### 01 / Air quality snapshot")
avg_aqi = filtered[aqi_col].mean()
median_aqi = filtered[aqi_col].median()
worst = filtered.loc[filtered[aqi_col].idxmax()] if filtered[aqi_col].notna().any() else None
best = filtered.loc[filtered[aqi_col].idxmin()] if filtered[aqi_col].notna().any() else None

k1, k2, k3, k4 = st.columns(4)
k1.metric("Average AQI", f"{avg_aqi:.1f}" if pd.notna(avg_aqi) else "—")
k2.metric("Median AQI", f"{median_aqi:.1f}" if pd.notna(median_aqi) else "—")
k3.metric("Highest recorded AQI", f"{worst[aqi_col]:.1f}" if worst is not None else "—")
k4.metric("Records analysed", f"{len(filtered):,}")

if worst is not None:
    place = str(worst[city_col]) if city_col else "Selected dataset"
    st.caption(f"Highest observation in the current selection: **{place}**.")
st.divider()

# ---------- City leaderboard ----------
st.markdown("### 02 / City leaderboard")
if city_col:
    city_stats = filtered.groupby(city_col)[aqi_col].agg(["mean", "median", "max", "count"]).reset_index()
    city_stats = city_stats.sort_values("mean", ascending=False)
    left, right = st.columns([1.2, 1])
    with left:
        fig = px.bar(city_stats.head(15), x="mean", y=city_col, orientation="h",
                     labels={"mean":"Average AQI", city_col:"City"},
                     title="15 cities with highest average AQI")
        fig.update_layout(template="plotly_dark", height=440, yaxis={"categoryorder":"total ascending"})
        st.plotly_chart(fig, use_container_width=True)
    with right:
        st.dataframe(city_stats.rename(columns={"mean":"Average AQI","median":"Median AQI","max":"Peak AQI","count":"Records"}),
                     use_container_width=True, hide_index=True, height=440)
else:
    st.info("A city column was not detected, so the city leaderboard is unavailable.")

# ---------- City comparison ----------
st.markdown("### 03 / City comparison studio")
if city_col:
    available = sorted(filtered[city_col].dropna().astype(str).unique())
    if len(available) >= 2:
        default_pair = available[:2]
        pair = st.multiselect("Select up to four cities to compare", available, default=default_pair, max_selections=4, key="compare_cities")
        comp = filtered[filtered[city_col].astype(str).isin(pair)]
        if not comp.empty and pair:
            comp_stats = comp.groupby(city_col)[aqi_col].agg(["mean","median","max"]).reset_index()
            fig = go.Figure()
            for metric, label in [("mean","Average"),("median","Median"),("max","Peak")]:
                fig.add_trace(go.Bar(name=label, x=comp_stats[city_col], y=comp_stats[metric]))
            fig.update_layout(barmode="group", template="plotly_dark", title="AQI profile by selected city",
                              yaxis_title="AQI", height=380)
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.caption("At least two cities are needed for comparison.")

# ---------- Time heatmap ----------
st.markdown("### 04 / Monthly pollution calendar")
if date_col and filtered[date_col].notna().any():
    time_df = filtered.dropna(subset=[date_col, aqi_col]).copy()
    time_df["Year"] = time_df[date_col].dt.year.astype(str)
    time_df["Month"] = time_df[date_col].dt.month
    monthly = time_df.groupby(["Year","Month"])[aqi_col].mean().reset_index()
    if not monthly.empty:
        pivot = monthly.pivot(index="Year", columns="Month", values=aqi_col)
        pivot = pivot.reindex(columns=range(1,13))
        fig = px.imshow(pivot, aspect="auto", color_continuous_scale="YlOrRd",
                        labels=dict(x="Month", y="Year", color="Average AQI"),
                        x=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
                        title="Average AQI by month and year")
        fig.update_layout(template="plotly_dark", height=330)
        st.plotly_chart(fig, use_container_width=True)
else:
    st.info("A date column was not detected; monthly heatmap is unavailable.")

# ---------- Pollutant fingerprint ----------
st.markdown("### 05 / Pollutant fingerprint")
if pollutants:
    means = filtered[pollutants].mean(numeric_only=True).dropna()
    if len(means) >= 3:
        # Normalize each pollutant against its maximum mean in the filtered dataset for visual comparison.
        scale = means / means.max() * 100
        fig = go.Figure()
        fig.add_trace(go.Scatterpolar(r=scale.values, theta=scale.index, fill="toself", name="Relative mean level"))
        fig.update_layout(template="plotly_dark", polar=dict(radialaxis=dict(visible=True, range=[0,100])),
                          title="Relative average pollutant profile (scaled within this selection)", height=420)
        st.plotly_chart(fig, use_container_width=True)
    st.dataframe(means.rename("Mean concentration").to_frame(), use_container_width=True)
else:
    st.info("No familiar pollutant columns were detected. Expected examples include PM2.5, PM10, NO2, SO2, CO or O3.")

# ---------- AQI distribution + quality ----------
st.markdown("### 06 / Distribution and data quality")
left, right = st.columns(2)
with left:
    fig = px.histogram(filtered, x=aqi_col, nbins=30, marginal="box", title="AQI distribution",
                       labels={aqi_col:"AQI"})
    fig.update_layout(template="plotly_dark", height=380)
    st.plotly_chart(fig, use_container_width=True)
with right:
    quality = pd.DataFrame({
        "Measure":["Rows","Columns","Duplicate rows","Missing AQI values","Missing city values"],
        "Result":[len(filtered), filtered.shape[1], int(filtered.duplicated().sum()),
                  int(filtered[aqi_col].isna().sum()), int(filtered[city_col].isna().sum()) if city_col else "City field unavailable"]
    })
    st.markdown("**Dataset quality check**")
    st.dataframe(quality, hide_index=True, use_container_width=True)
    missing = filtered.isna().mean().mul(100).sort_values(ascending=False).head(10).reset_index()
    missing.columns = ["Column","Missing (%)"]
    st.markdown("**Top missing-value columns**")
    st.dataframe(missing.round(1), hide_index=True, use_container_width=True)

# ---------- Export ----------
st.divider()
st.markdown("### 07 / Export your filtered analysis")
csv = filtered.to_csv(index=False).encode("utf-8")
st.download_button("⬇️ Download filtered data as CSV", data=csv,
                   file_name="smog_city_filtered_analysis.csv", mime="text/csv")
st.caption("Note: This dashboard analyses the uploaded historical dataset; it does not provide live AQI readings or medical advice.")
